@extends('layout')
@section('content')
    <!-- Nội dung chính -->
    <div class="text-center">
        <img src="{{ asset('fe/images/anhgiaodien.jpg') }}" height="500px" width="100%" class="mt-4 img img-responsive"
            alt="MB Banner">
    </div>
@endsection
