

<?php $__env->startSection('content'); ?>
    <h4>THÊM MỚI KHÁCH HÀNG DOANH NGHIỆP</h4>

    <form method="POST" action="<?php echo e(route('khachhangdoanhnghiep.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <fieldset class="border p-3 mb-3">
            <legend class="float-none w-auto px-2">Thông tin khách hàng doanh nghiệp</legend>

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Mã khách hàng</label>
                    <input type="text" name="MaKH" class="form-control" value="<?php echo e(old('MaKH')); ?>">
                    <?php $__errorArgs = ['MaKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tên doanh nghiệp</label>
                    <input type="text" name="TenDN" class="form-control" value="<?php echo e(old('TenDN')); ?>">
                    <?php $__errorArgs = ['TenDN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Ngày thành lập</label>
                    <input type="date" name="NgayThanhLap" class="form-control" value="<?php echo e(old('NgayThanhLap')); ?>">
                    <?php $__errorArgs = ['NgayThanhLap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Mã số thuế</label>
                    <input type="text" name="MaSoThue" class="form-control" value="<?php echo e(old('MaSoThue')); ?>">
                    <?php $__errorArgs = ['MaSoThue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tên đại diện pháp lý</label>
                    <input type="text" name="TenDaiDienPL" class="form-control" value="<?php echo e(old('TenDaiDienPL')); ?>">
                    <?php $__errorArgs = ['TenDaiDienPL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Chức vụ</label>
                    <input type="text" name="ChucVu" class="form-control" value="<?php echo e(old('ChucVu')); ?>">
                    <?php $__errorArgs = ['ChucVu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tên kế toán</label>
                    <input type="text" name="TenKeToan" class="form-control" value="<?php echo e(old('TenKeToan')); ?>">
                    <?php $__errorArgs = ['TenKeToan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">CCCD kế toán</label>
                    <input type="text" name="CCCDKT" class="form-control" value="<?php echo e(old('CCCDKT')); ?>">
                    <?php $__errorArgs = ['CCCDKT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Email kế toán</label>
                    <input type="email" name="EmailKT" class="form-control" value="<?php echo e(old('EmailKT')); ?>">
                    <?php $__errorArgs = ['EmailKT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Vốn điều lệ</label>
                    <input type="number" name="VonDieuLe" class="form-control" value="<?php echo e(old('VonDieuLe')); ?>">
                    <?php $__errorArgs = ['VonDieuLe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Địa chỉ doanh nghiệp</label>
                    <input type="text" name="DiaChiDN" class="form-control" value="<?php echo e(old('DiaChiDN')); ?>">
                    <?php $__errorArgs = ['DiaChiDN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Hồ sơ doanh nghiệp</label>
                    <input type="file" name="HoSoDN" class="form-control">
                    <?php $__errorArgs = ['HoSoDN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>


    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/khachhangdoanhnghiep/create.blade.php ENDPATH**/ ?>