

<?php $__env->startSection('content'); ?>
    <h4>Danh Sách Loại Tài Khoản</h4>

    <!-- Display success message if any -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Nút thêm mới -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('loaitk.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>
    <!-- Table displaying the records -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã Loại Tài Khoản</th>
                <th>Tên Loại Tài Khoản</th>
                <th>Chức Năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $loaitk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($key + 1); ?></td>
                    <td class="text-center"><?php echo e($item->MaLoaiTK); ?></td>
                    <td><?php echo e($item->TenLoaiTK); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('loaitk.edit', $item->MaLoaiTK)); ?>"
                            class="btn btn-warning btn-sm btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaitk/index.blade.php ENDPATH**/ ?>