

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Danh Sách Chức Vụ</h4>

    <div class="mb-3 text-end">
        <a href="<?php echo e(route('chucvu.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã Chức Vụ</th>
                <th>Tên Chức Vụ</th>
                <th>Phòng Ban</th>
                <th>Chức Năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $chucvus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chucvu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td><?php echo e($chucvu->MaCV); ?></td>
                    <td><?php echo e($chucvu->TenCV); ?></td>
                    <td><?php echo e($chucvu->phongban->TenPB); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('chucvu.edit', $chucvu->MaCV)); ?>" class="btn btn-warning btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/chucvu/index.blade.php ENDPATH**/ ?>