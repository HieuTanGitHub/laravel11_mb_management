

<?php $__env->startSection('content'); ?>
    <h4>CHỈNH SỬA LOẠI THẺ</h4>

    <form action="<?php echo e(route('loaithe.update', $loaithe->MaLoaiThe)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Mã Loại Thẻ</label>
            <input type="text" name="MaLoaiThe" class="form-control" value="<?php echo e($loaithe->MaLoaiThe); ?>" readonly>
        </div>

        <div class="mb-3">
            <label class="form-label">Tên Loại Thẻ</label>
            <input type="text" name="TenLoaiThe" class="form-control"
                value="<?php echo e(old('TenLoaiThe', $loaithe->TenLoaiThe)); ?>">
            <?php $__errorArgs = ['TenLoaiThe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-success">Cập Nhật</button>
        <a href="<?php echo e(route('loaithe.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaithe/edit.blade.php ENDPATH**/ ?>