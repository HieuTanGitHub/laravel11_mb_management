


<?php $__env->startSection('content'); ?>
    <h4>Chỉnh sửa chức vụ</h4>

    <!-- Form to edit the ChucVu -->
    <form method="POST" action="<?php echo e(route('chucvu.update', $chucvu->MaCV)); ?>">
        <?php echo csrf_field(); ?>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Mã chức vụ</label>
                <input type="text" name="MaCV" class="form-control" value="<?php echo e($chucvu->MaCV); ?>" readonly>
            </div>

            <div class="col-md-4">
                <label class="form-label">Tên chức vụ</label>
                <input type="text" name="TenCV" class="form-control" value="<?php echo e(old('TenCV', $chucvu->TenCV)); ?>" required>
                <?php $__errorArgs = ['TenCV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4">
                <label class="form-label">Phòng ban</label>
                <select name="MaPB" class="form-control">
                    <?php $__currentLoopData = $phongbans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phongban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($phongban->MaPB); ?>" <?php echo e($phongban->MaPB == $chucvu->MaPB ? 'selected' : ''); ?>>
                            <?php echo e($phongban->TenPB); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['MaPB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="text-end mt-3">
            <button type="submit" class="btn btn-save btn-custom">Cập nhật</button>
            <a href="<?php echo e(route('chucvu.index')); ?>" class="btn btn-cancel btn-custom">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/chucvu/edit.blade.php ENDPATH**/ ?>