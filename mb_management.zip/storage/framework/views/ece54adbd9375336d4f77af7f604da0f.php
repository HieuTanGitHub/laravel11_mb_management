

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Thêm Mới Chức Vụ</h4>

    <form method="POST" action="<?php echo e(route('chucvu.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Mã Chức Vụ</label>
            <input type="text" name="MaCV" class="form-control" value="<?php echo e(old('MaCV')); ?>">
            <?php $__errorArgs = ['MaCV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Tên Chức Vụ</label>
            <input type="text" name="TenCV" class="form-control" value="<?php echo e(old('TenCV')); ?>">
            <?php $__errorArgs = ['TenCV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Mã Phòng Ban</label>
            <select name="MaPB" class="form-control">
                <?php $__currentLoopData = $phongbans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phongban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($phongban->MaPB); ?>" <?php echo e(old('MaPB') == $phongban->MaPB ? 'selected' : ''); ?>>
                        <?php echo e($phongban->TenPB); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['MaPB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Thêm Mới</button>
        <a href="<?php echo e(route('chucvu.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/chucvu/create.blade.php ENDPATH**/ ?>