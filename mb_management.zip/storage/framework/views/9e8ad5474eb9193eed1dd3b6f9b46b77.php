

<?php $__env->startSection('content'); ?>
    <h4>Thêm Mới Loại Tài Khoản</h4>

    <!-- Display validation errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form nhập thông tin loại tài khoản -->
    <form method="POST" action="<?php echo e(route('loaitk.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Mã Loại Tài Khoản</label>
                <input type="text" name="MaLoaiTK" class="form-control" value="<?php echo e(old('MaLoaiTK')); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Tên Loại Tài Khoản</label>
                <input type="text" name="TenLoaiTK" class="form-control" value="<?php echo e(old('TenLoaiTK')); ?>" required>
            </div>
        </div>

        <!-- Nút hành động -->
        <div class="text-end mt-3">
            <button type="submit" class="btn btn-success">Lưu</button>
            <a href="<?php echo e(route('loaitk.index')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaitk/create.blade.php ENDPATH**/ ?>