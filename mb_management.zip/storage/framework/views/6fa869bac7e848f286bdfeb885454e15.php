

<?php $__env->startSection('content'); ?>
    <h4>Cập nhật thông tin nhân viên</h4>

    <form method="POST" action="<?php echo e(route('nhanvien.update', $nhanvien->MaNV)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Mã nhân viên</label>
                <input type="text" name="MaNV" class="form-control" value="<?php echo e(old('MaNV', $nhanvien->MaNV)); ?>" readonly>
            </div>

            <div class="col-md-4">
                <label class="form-label">Họ và tên</label>
                <input type="text" name="HoTen" class="form-control" value="<?php echo e(old('HoTen', $nhanvien->HoTen)); ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label">Số điện thoại</label>
                <input type="text" name="SDT" class="form-control" value="<?php echo e(old('SDT', $nhanvien->SDT)); ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label">Tên đăng nhập</label>
                <input type="text" name="TenDangNhap" class="form-control"
                    value="<?php echo e(old('TenDangNhap', $nhanvien->TenDangNhap)); ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="Email" class="form-control" value="<?php echo e(old('Email', $nhanvien->Email)); ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label">Phân quyền</label>
                <input type="text" name="PhanQuyen" class="form-control"
                    value="<?php echo e(old('PhanQuyen', $nhanvien->PhanQuyen)); ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label">Mã phòng ban</label>
                <select name="MaPB" class="form-control">
                    <?php $__currentLoopData = $phongbans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phongban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($phongban->MaPB); ?>" <?php echo e($nhanvien->MaPB == $phongban->MaPB ? 'selected' : ''); ?>>
                            <?php echo e($phongban->TenPB); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label">Mã chức vụ</label>
                <select name="MaCV" class="form-control">
                    <?php $__currentLoopData = $chucvus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chucvu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chucvu->MaCV); ?>" <?php echo e($nhanvien->MaCV == $chucvu->MaCV ? 'selected' : ''); ?>>
                            <?php echo e($chucvu->TenCV); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

        </div>

        <!-- Action Buttons -->
        <div class="text-end mt-3">
            <button class="btn btn-success" type="submit">Cập nhật</button>
            <a href="<?php echo e(route('nhanvien.index')); ?>" class="btn btn-secondary">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/nhanvien/edit.blade.php ENDPATH**/ ?>