

<?php $__env->startSection('content'); ?>
    <h4>Danh Sách Loại Thẻ</h4>
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('loaithe.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>
    <!-- Hiển thị thông báo thành công -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã Loại Thẻ</th>
                <th>Tên Loại Thẻ</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $loaithe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($key + 1); ?></td>
                    <td class="text-center"><?php echo e($lt->MaLoaiThe); ?></td>
                    <td><?php echo e($lt->TenLoaiThe); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('loaithe.edit', $lt->MaLoaiThe)); ?>" class="btn btn-warning btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaithe/index.blade.php ENDPATH**/ ?>