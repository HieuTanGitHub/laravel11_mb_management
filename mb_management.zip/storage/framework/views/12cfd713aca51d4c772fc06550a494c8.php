
<?php $__env->startSection('content'); ?>
    <!-- Nội dung chính -->
    <div class="text-center">
        <img src="<?php echo e(asset('fe/images/anhgiaodien.jpg')); ?>" height="500px" width="100%" class="mt-4 img img-responsive"
            alt="MB Banner">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/dashboard.blade.php ENDPATH**/ ?>