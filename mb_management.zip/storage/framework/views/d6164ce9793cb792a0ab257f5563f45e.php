<table class="table table-bordered">
    <tr>
        <th>Mã Giao Dịch</th>
        <td><?php echo e($thanhtoan->MaGDThanhToan); ?></td>
    </tr>
    <tr>
        <th>Số Tài Khoản</th>
        <td><?php echo e($thanhtoan->SoTK); ?></td>
    </tr>
    <tr>
        <th>Chủ Tài Khoản</th>
        <td><?php echo e($khachhang->TenKH); ?></td>
    </tr>
    <tr>
        <th>CCCD</th>
        <td><?php echo e($khachhang->CCCD); ?></td>
    </tr>
    <tr>
        <th>Số Thẻ</th>
        <td><?php echo e($the->SoThe); ?></td>
    </tr>
    <tr>
        <th>Số Tiền Rút</th>
        <td><?php echo e(number_format($thanhtoan->SoTienThanhToan)); ?> VNĐ</td>
    </tr>
    <tr>
        <th>Phí Giao Dịch</th>
        <td><?php echo e(number_format($thanhtoan->PhiGiaoDich)); ?> VNĐ</td>
    </tr>
    <tr>
        <th>Nội Dung</th>
        <td><?php echo e($thanhtoan->NoiDung); ?></td>
    </tr>
    <tr>
        <th>Ngày Tạo</th>
        <td><?php echo e($thanhtoan->NgayTao); ?></td>
    </tr>
</table>
<?php /**PATH C:\xampp\htdocs\mb_management\resources\views/giaodich/thanhtoanhoadon/chitiet.blade.php ENDPATH**/ ?>