

<?php $__env->startSection('content'); ?>
    <h4>CẬP NHẬT LOẠI KHÁCH HÀNG</h4>

    <!-- Hiển thị thông báo lỗi -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form cập nhật -->
    <form method="POST" action="<?php echo e(route('loaikhachhang.update', $loaikhachhang->MaLoaiKH)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <fieldset class="border p-3 mb-3">
            <legend class="float-none w-auto px-2">Chỉnh sửa thông tin</legend>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Mã Loại KH</label>
                    <input type="text" name="MaLoaiKH" class="form-control"
                        value="<?php echo e(old('MaLoaiKH', $loaikhachhang->MaLoaiKH)); ?>" readonly>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tên Loại KH</label>
                    <input type="text" name="TenLoaiKH" class="form-control"
                        value="<?php echo e(old('TenLoaiKH', $loaikhachhang->TenLoaiKH)); ?>">
                    <?php $__errorArgs = ['TenLoaiKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Mô Tả</label>
                    <textarea name="MoTa" class="form-control"><?php echo e(old('MoTa', $loaikhachhang->MoTa)); ?></textarea>
                    <?php $__errorArgs = ['MoTa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>

        <!-- Nút hành động -->
        <div class="text-end">
            <button type="submit" class="btn btn-save btn-custom">Cập nhật</button>
            <a href="<?php echo e(route('loaikhachhang.index')); ?>" class="btn btn-cancel btn-custom">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaikhachhang/edit.blade.php ENDPATH**/ ?>