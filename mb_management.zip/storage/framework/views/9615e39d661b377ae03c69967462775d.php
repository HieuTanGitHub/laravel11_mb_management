

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Chỉnh sửa thông tin khách hàng doanh nghiệp</h4>

    <form action="<?php echo e(route('khachhangdoanhnghiep.update', $khachhang->MaKH)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Mã KH</label>
                <input type="text" name="MaKH" class="form-control" value="<?php echo e(old('MaKH', $khachhang->MaKH)); ?>" disabled>
            </div>
            <div class="col-md-4">
                <label class="form-label">Tên Doanh Nghiệp</label>
                <input type="text" name="TenDN" class="form-control" value="<?php echo e(old('TenDN', $khachhang->TenDN)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Mã Số Thuế</label>
                <input type="text" name="MaSoThue" class="form-control"
                    value="<?php echo e(old('MaSoThue', $khachhang->MaSoThue)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Tên Đại Diện PL</label>
                <input type="text" name="TenDaiDienPL" class="form-control"
                    value="<?php echo e(old('TenDaiDienPL', $khachhang->TenDaiDienPL)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Chức Vụ</label>
                <input type="text" name="ChucVu" class="form-control" value="<?php echo e(old('ChucVu', $khachhang->ChucVu)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Email Kế Toán</label>
                <input type="email" name="EmailKT" class="form-control" value="<?php echo e(old('EmailKT', $khachhang->EmailKT)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Hồ Sơ Doanh Nghiệp</label>
                <input type="file" name="HoSoDN" class="form-control">
                <?php if($khachhang->HoSoDN): ?>
                    <a href="<?php echo e(asset('storage/' . $khachhang->HoSoDN)); ?>" target="_blank" class="btn btn-info mt-2">Xem Hồ
                        Sơ</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-end mt-3">
            <button type="submit" class="btn btn-success">Cập nhật</button>
            <a href="<?php echo e(route('khachhangdoanhnghiep.index')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/khachhangdoanhnghiep/edit.blade.php ENDPATH**/ ?>