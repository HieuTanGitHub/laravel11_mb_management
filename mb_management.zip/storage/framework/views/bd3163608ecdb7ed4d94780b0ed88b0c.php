

<?php $__env->startSection('content'); ?>
    <h4>Danh Sách Thẻ</h4>
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('the.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Số Thẻ</th>
                <th>Ngày Mở</th>
                <th>Ngày Hết Hạn</th>
                <th>Loại Thẻ</th>
                <th>Nhân Viên</th>
                <th>Khách Hàng</th>
                <th>Số Tài Khoản</th>
                <th>Trạng Thái</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $theList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($the->SoThe); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($the->NgayMo))); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($the->NgayHetHan))); ?></td>
                    <td><?php echo e($the->loaiThe->TenLoaiThe ?? 'N/A'); ?></td>
                    <td><?php echo e($the->nhanvien->HoTen ?? 'N/A'); ?></td>
                    <td><?php echo e($the->khachhang->TenKH ?? 'N/A'); ?></td>
                    <td><?php echo e($the->SoTK); ?></td>
                    <td>
                        <?php if($the->getTrangThaiAttribute() == 'Còn hạn'): ?>
                            <span class="badge bg-success">Còn hạn</span>
                        <?php elseif($the->getTrangThaiAttribute() == 'Hết hạn'): ?>
                            <span class="badge bg-danger">Hết hạn</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Đã đóng</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('the.edit', $the->SoThe)); ?>" class="btn btn-warning btn-sm btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/the/index.blade.php ENDPATH**/ ?>