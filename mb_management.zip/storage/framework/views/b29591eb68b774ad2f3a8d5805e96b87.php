

<?php $__env->startSection('content'); ?>
    <h4>THÊM MỚI KHÁCH HÀNG CÁ NHÂN</h4>
    <style>
        .col-md-6.check-form {
            display: inline-table;
        }
    </style>
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Ngày tạo</label>
            <input type="text" readonly name="NgayTao" class="form-control" value="<?php echo e(\Carbon\Carbon::now()); ?>">

        </div>
        <div class="col-md-6">
            <label class="form-label">Người tạo</label>
            <input type="text" readonly name="NguoiTao" class="form-control" value="<?php echo e(Session::get('TenDangNhap')); ?>">

        </div>
    </div>
    <!-- Form nhập thông tin khách hàng -->
    <form method="POST" action="<?php echo e(route('khachhangcanhan.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <fieldset class="border p-3 mb-3">
            <legend class="float-none w-auto px-2">Nhập thông tin khách hàng</legend>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Mã Khách Hàng</label>
                    <input type="text" name="MaKH" readonly class="form-control" value="KHCN<?php echo e(rand(0000, 9999)); ?>">
                    <?php $__errorArgs = ['MaKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Nghề Nghiệp</label>
                    <input type="text" name="NgheNghiep" class="form-control" value="<?php echo e(old('NgheNghiep')); ?>">
                    <?php $__errorArgs = ['NgheNghiep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Doanh Thu</label>
                    <input type="number" name="DoanhThu" class="form-control" value="<?php echo e(old('DoanhThu')); ?>">
                    <?php $__errorArgs = ['DoanhThu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Hồ Sơ Cá Nhân (File PDF, DOCX)</label>
                    <input type="file" name="HoSoCaNhan" class="form-control">
                    <?php $__errorArgs = ['HoSoCaNhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tên Khách Hàng</label>
                    <input type="text" name="TenKH" class="form-control" value="<?php echo e(old('TenKH')); ?>">
                    <?php $__errorArgs = ['TenKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">CCCD</label>
                    <input type="text" name="CCCD" class="form-control" value="<?php echo e(old('CCCD')); ?>">
                    <?php $__errorArgs = ['CCCD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="text" name="Email" class="form-control" value="<?php echo e(old('Email')); ?>">
                    <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Ngày Sinh</label>
                    <input type="date" name="NgaySinh" class="form-control" value="<?php echo e(old('NgaySinh')); ?>">
                    <?php $__errorArgs = ['NgaySinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Số Điện Thoại</label>
                    <input type="text" name="SDT" class="form-control" value="<?php echo e(old('SDT')); ?>">
                    <?php $__errorArgs = ['SDT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Tỉnh thành phố</label>
                    <select name="Thanhpho" id="city" class="form-control choose city">
                        <option value="">--Chọn tỉnh thành phố--</option>
                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ci->matp); ?>"><?php echo e($ci->name_city); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div class="col-md-6">
                    <label class="form-label">Quận huyện</label>
                    <select name="Quanhuyen" id="province" class="form-control choose province city">
                        <option value="">--Chọn quận huyện--</option>

                    </select>

                </div>
                <div class="col-md-6">
                    <label class="form-label">Xã phường</label>
                    <select name="Xaphuong" id="wards" class="form-control wards">
                        <option value="">--Chọn Xã phường--</option>

                    </select>

                </div>
                <div class="col-md-6">
                    <label class="form-label">Số Tài Khoản</label>
                    <input type="text" name="SoTK" class="form-control" value="<?php echo e(old('SoTK')); ?>">
                    <?php $__errorArgs = ['SoTK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 check-form">
                    <label class="form-label">Thẻ cứng</label>
                    <div class="form-check">
                        <input class="form-check-input" value="có" type="radio" name="TheCung"
                            id="flexRadioDefault1" checked>
                        <label class="form-check-label" for="flexRadioDefault1">
                            Có
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" value="Không" type="radio" name="TheCung"
                            id="flexRadioDefault2">
                        <label class="form-check-label" for="flexRadioDefault2">
                            Không
                        </label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Loại Tài Khoản</label>
                    <select name="MaLoaiTK" class="form-control">
                        <?php $__currentLoopData = $loaitaikhoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loaitk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($loaitk->MaLoaiTK); ?>"><?php echo e($loaitk->TenLoaiTK); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['MaLoaiTK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Loại Khách Hàng</label>
                    <select name="MaLoaiKH" class="form-control">
                        <?php $__currentLoopData = $loaikhachhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loaikh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($loaikh->MaLoaiKH); ?>"><?php echo e($loaikh->TenLoaiKH); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['LoaiKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Trạng Thái</label>
                    <select name="TrangThai" class="form-control">
                        <option>Kích hoạt</option>
                        <option>Khóa</option>
                    </select>
                    <?php $__errorArgs = ['TrangThai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>
        <!-- Nút hành động -->
        <div class="text-end">
            <button type="submit" class="btn btn-save btn-custom">Lưu</button>
            <a href="<?php echo e(route('khachhangcanhan.index')); ?>" class="btn btn-cancel btn-custom">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/khachhangcanhan/create.blade.php ENDPATH**/ ?>