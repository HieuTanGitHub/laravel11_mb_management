

<?php $__env->startSection('content'); ?>
    <h4>Danh sách nhân viên</h4>
    <!-- Display success message if available -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Nút thêm mới -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('nhanvien.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>
    <!-- Table to display employee data -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã nhân viên</th>
                <th>Họ và tên</th>
                <th>Số điện thoại</th>
                <th>Email</th>
                <th>Chức vụ</th>
                <th>Phòng ban</th>
                <th>Chức năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $nhanviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nhanvien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($key + 1); ?></td>
                    <td class="text-center"><?php echo e($nhanvien->MaNV); ?></td>
                    <td><?php echo e($nhanvien->HoTen); ?></td>
                    <td class="text-center"><?php echo e($nhanvien->SDT); ?></td>
                    <td class="text-center"><?php echo e($nhanvien->Email); ?></td>
                    <td class="text-center"><?php echo e($nhanvien->chucvu->TenCV); ?></td>
                    <td class="text-center"><?php echo e($nhanvien->phongban->TenPB); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('nhanvien.edit', $nhanvien->MaNV)); ?>" class="btn btn-edit btn-custom">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/nhanvien/index.blade.php ENDPATH**/ ?>