

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Danh Sách Phòng Ban</h4>


    <!-- Nút thêm mới -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('phongban.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>

    <!-- Bảng Danh Sách Phòng Ban -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã Phòng Ban</th>
                <th>Tên Phòng Ban</th>
                <th>Chức Năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $phongbans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $phongban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td class="text-center"><?php echo e($phongban->MaPB); ?></td>
                    <td><?php echo e($phongban->TenPB); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('phongban.edit', $phongban->MaPB)); ?>"
                            class="btn btn-warning btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/phongban/index.blade.php ENDPATH**/ ?>