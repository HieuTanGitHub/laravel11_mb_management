

<?php $__env->startSection('content'); ?>
    <h2 class="title">QUẢN LÝ THÔNG TIN CHUNG GIAO DỊCH</h2>
    <form class="search-form" action="" method="GET">
        <input type="text" name="keyword" placeholder="0308119826XXX">
        <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>


    <!-- Hiển thị thông báo thành công -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <!-- Nút thêm mới -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('giaodich.themthanhtoanhoadon')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã Giao Dịch</th>
                <th>Thời gian giao dịch</th>
                <th>Loại giao dịch</th>
                <th>Chức Năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $thanhtoanhoadon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($key + 1); ?></td>
                    <td><?php echo e($tt->MaGDThanhToan); ?></td>
                    <td class="text-center"><?php echo e($tt->NgayTao); ?></td>
                    <td class="text-center"><?php echo e($tt->LoaiGiaoDich); ?></td>


                    <td class="text-center">
                        <a class="btn btn-warning btn-edit-chitiet-giaodich-thanhtoan btn-edit-chitiet"
                            data-id="<?php echo e($tt->MaGDThanhToan); ?>">
                            Chi tiết
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="modal fade" id="modal-chitiet" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Chi tiết giao dịch thanh toán hóa đơn</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="info">
                    <!-- Dữ liệu ajax sẽ load vào đây -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/giaodich/thanhtoanhoadon/index.blade.php ENDPATH**/ ?>