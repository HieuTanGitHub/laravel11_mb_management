

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Danh sách khách hàng doanh nghiệp</h4>
    <!-- Nút thêm mới -->
    <div class="mb-3 text-end">
        <a href="<?php echo e(route('khachhangdoanhnghiep.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>STT</th>
                <th>Mã KH</th>
                <th>Tên Doanh Nghiệp</th>
                <th>MST</th>
                <th>Đại Diện</th>
                <th>Chức Vụ</th>
                <th>Email Kế Toán</th>
                <th>Hồ Sơ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $khachhangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($key + 1); ?></td>
                    <td><?php echo e($kh->MaKH); ?></td>
                    <td><?php echo e($kh->TenDN); ?></td>
                    <td><?php echo e($kh->MaSoThue); ?></td>
                    <td><?php echo e($kh->TenDaiDienPL); ?></td>
                    <td><?php echo e($kh->ChucVu); ?></td>
                    <td><?php echo e($kh->EmailKT); ?></td>
                    <td class="text-center">
                        <?php if($kh->HoSoDN): ?>
                            <a href="<?php echo e(asset('storage/' . $kh->HoSoDN)); ?>" target="_blank" download class="btn btn-primary">
                                Tải Xuống
                            </a>
                        <?php else: ?>
                            <span class="text-muted">Chưa có</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <a href="<?php echo e(route('khachhangdoanhnghiep.edit', $kh->MaKH)); ?>"
                            class="btn btn-warning btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/khachhangdoanhnghiep/index.blade.php ENDPATH**/ ?>