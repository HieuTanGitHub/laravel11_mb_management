

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Thêm Mới Phòng Ban</h4>

    <form action="<?php echo e(route('phongban.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Mã Phòng Ban</label>
                <input type="text" name="MaPB" class="form-control" value="<?php echo e(old('MaPB')); ?>">
                <?php $__errorArgs = ['MaPB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
                <label class="form-label">Tên Phòng Ban</label>
                <input type="text" name="TenPB" class="form-control" value="<?php echo e(old('TenPB')); ?>">
                <?php $__errorArgs = ['TenPB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="text-end mt-3">
            <button type="submit" class="btn btn-success">Lưu</button>
            <a href="<?php echo e(route('phongban.index')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/phongban/create.blade.php ENDPATH**/ ?>