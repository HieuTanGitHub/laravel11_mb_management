

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Danh Sách Tài Khoản</h2>
        <div class="mb-3 text-end">
            <a href="<?php echo e(route('taikhoan.create')); ?>" class="btn btn-add btn-custom">
                <i class="fa fa-plus"></i> Thêm Mới
            </a>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Số TK</th>
                    <th>Số Dư</th>
                    <th>Ngày Mở</th>
                    <th>Ngày Đóng</th>
                    <th>Trạng Thái</th>
                    <th>Loại Thẻ</th>
                    <th>Nhân Viên</th>
                    <th>Khách Hàng</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $taiKhoans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tk->SoTK); ?></td>
                        <td><?php echo e(number_format($tk->SoDuTK, 0, ',', '.')); ?> VND</td>
                        <td><?php echo e(\Carbon\Carbon::parse($tk->NgayMo)->format('d/m/Y')); ?></td>
                        <td><?php echo e($tk->NgayDong ? \Carbon\Carbon::parse($tk->NgayDong)->format('d/m/Y') : '---'); ?></td>
                        <td>
                            <span class="badge <?php echo e($tk->TrangThai ? 'bg-success' : 'bg-danger'); ?>">
                                <?php echo e($tk->TrangThai ? 'Còn hiệu lực' : 'Đã đóng'); ?>

                            </span>
                        </td>
                        <td><?php echo e($tk->loaiThe->TenLoaiThe ?? 'N/A'); ?></td>
                        <td><?php echo e($tk->nhanVien->HoTen ?? 'N/A'); ?></td>
                        <td><?php echo e($tk->khachHang->TenKH ?? 'N/A'); ?></td>
                        <td>
                            <a href="<?php echo e(route('taikhoan.edit', $tk->SoTK)); ?>"
                                class="btn btn-warning btn-sm btn-edit-style">Sửa</a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/taikhoan/index.blade.php ENDPATH**/ ?>