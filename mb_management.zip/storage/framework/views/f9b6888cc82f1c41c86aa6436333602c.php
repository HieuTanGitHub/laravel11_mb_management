

<?php $__env->startSection('content'); ?>
    <h4>THÊM MỚI LOẠI HOẠT ĐỘNG</h4>

    <form action="<?php echo e(route('loaihoatdong.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Mã Loại Hoạt Động</label>
            <input type="text" name="MaLoaiHD" class="form-control" value="<?php echo e(old('MaLoaiHD')); ?>">
            <?php $__errorArgs = ['MaLoaiHD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Tên Loại Hoạt Động</label>
            <input type="text" name="TenLoaiHD" class="form-control" value="<?php echo e(old('TenLoaiHD')); ?>">
            <?php $__errorArgs = ['TenLoaiHD'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Mô Tả</label>
            <textarea name="MoTa" class="form-control"><?php echo e(old('MoTa')); ?></textarea>
            <?php $__errorArgs = ['MoTa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-success">Thêm Mới</button>
        <a href="<?php echo e(route('loaihoatdong.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaihoatdong/create.blade.php ENDPATH**/ ?>