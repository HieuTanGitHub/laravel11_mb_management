

<?php $__env->startSection('content'); ?>
    <h4>Thêm Mới Thẻ</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('the.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Số Thẻ</label>
            <input type="text" name="SoThe" class="form-control" value="<?php echo e(old('SoThe')); ?>" required>
            <?php $__errorArgs = ['SoThe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ngày Mở</label>
            <input type="date" name="NgayMo" class="form-control" value="<?php echo e(old('NgayMo')); ?>" required>
            <?php $__errorArgs = ['NgayMo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ngày Hết Hạn</label>
            <input type="date" name="NgayHetHan" class="form-control" value="<?php echo e(old('NgayHetHan')); ?>" required>
            <?php $__errorArgs = ['NgayHetHan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Ngày Đóng (nếu có)</label>
            <input type="date" name="NgayDong" class="form-control" value="<?php echo e(old('NgayDong')); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Loại Thẻ</label>
            <select name="MaLoaiThe" class="form-control" required>
                <option value="">-- Chọn Loại Thẻ --</option>
                <?php $__currentLoopData = $loaiThe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($loai->MaLoaiThe); ?>"><?php echo e($loai->TenLoaiThe); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['MaLoaiThe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Nhân Viên (nếu có)</label>
            <select name="MaNV" class="form-control">
                <option value="">-- Chọn Nhân Viên --</option>
                <?php $__currentLoopData = $nhanviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($nv->MaNV); ?>"><?php echo e($nv->HoTen); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Khách Hàng (nếu có)</label>
            <select name="MaKH" class="form-control">
                <option value="">-- Chọn Khách Hàng --</option>
                <?php $__currentLoopData = $khachhangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kh->MaKH); ?>"><?php echo e($kh->TenKH); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Số Tài Khoản</label>
            <input type="text" name="SoTK" class="form-control" value="<?php echo e(old('SoTK')); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Thêm Thẻ</button>
        <a href="<?php echo e(route('the.index')); ?>" class="btn btn-secondary">Quay Lại</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/the/create.blade.php ENDPATH**/ ?>