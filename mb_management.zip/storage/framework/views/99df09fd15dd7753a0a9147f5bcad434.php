

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-4">Chỉnh Sửa Tài Khoản</h2>

        <form action="<?php echo e(route('taikhoan.update', $taiKhoan->SoTK)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row">
                <!-- Số tài khoản -->
                <div class="col-md-6">
                    <label class="form-label">Số Tài Khoản</label>
                    <input type="text" name="SoTK" class="form-control" value="<?php echo e($taiKhoan->SoTK); ?>" readonly>
                </div>

                <!-- Số dư tài khoản -->
                <div class="col-md-6">
                    <label class="form-label">Số Dư</label>
                    <input type="number" name="SoDuTK" class="form-control" value="<?php echo e($taiKhoan->SoDuTK); ?>" required>
                </div>

                <!-- Trạng thái -->
                <div class="col-md-6">
                    <label class="form-label">Trạng Thái</label>
                    <select name="TrangThai" class="form-control">
                        <option value="1" <?php echo e($taiKhoan->TrangThai ? 'selected' : ''); ?>>Còn hiệu lực</option>
                        <option value="0" <?php echo e(!$taiKhoan->TrangThai ? 'selected' : ''); ?>>Đã đóng</option>
                    </select>
                </div>

                <!-- Loại Thẻ -->
                <div class="col-md-6">
                    <label class="form-label">Loại Thẻ</label>
                    <select name="MaLoaiThe" class="form-control">
                        <?php $__currentLoopData = $loaiThes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($loai->MaLoaiThe); ?>"
                                <?php echo e($taiKhoan->MaLoaiThe == $loai->MaLoaiThe ? 'selected' : ''); ?>>
                                <?php echo e($loai->TenLoaiThe); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">

                    <label for="NgayMo" class="form-label">Ngày Mở</label>
                    <input type="date" class="form-control" id="NgayMo" name="NgayMo"
                        value="<?php echo e(old('NgayMo', \Carbon\Carbon::parse($taiKhoan->NgayMo)->format('Y-m-d'))); ?>" required>

                </div>


                <!-- Ngày đóng -->
                <div class="col-md-6">
                    <label class="form-label">Ngày đóng</label>
                    <input type="date" name="NgayDong" class="form-control"
                        value="<?php echo e(old('NgayMo', \Carbon\Carbon::parse($taiKhoan->NgayDong)->format('Y-m-d'))); ?>">
                    <?php $__errorArgs = ['NgayDong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Nhân viên -->
                <div class="col-md-6">
                    <label class="form-label">Nhân Viên</label>
                    <select name="MaNV" class="form-control">
                        <?php $__currentLoopData = $nhanViens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nv->MaNV); ?>" <?php echo e($taiKhoan->MaNV == $nv->MaNV ? 'selected' : ''); ?>>
                                <?php echo e($nv->HoTen); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Khách hàng -->
                <div class="col-md-6">
                    <label class="form-label">Khách Hàng</label>
                    <select name="MaKH" class="form-control">
                        <?php $__currentLoopData = $khachHangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kh->MaKH); ?>" <?php echo e($taiKhoan->MaKH == $kh->MaKH ? 'selected' : ''); ?>>
                                <?php echo e($kh->TenKH); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Submit -->
                <div class="col-md-12 mt-3">
                    <button type="submit" class="btn btn-primary">Cập Nhật</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/taikhoan/edit.blade.php ENDPATH**/ ?>