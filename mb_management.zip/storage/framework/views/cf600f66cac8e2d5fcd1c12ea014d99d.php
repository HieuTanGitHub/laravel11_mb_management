

<?php $__env->startSection('content'); ?>
    <h4>Danh Sách Loại Hoạt Động</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="mb-3 text-end">
        <a href="<?php echo e(route('loaihoatdong.create')); ?>" class="btn btn-add btn-custom">
            <i class="fa fa-plus"></i> Thêm Mới
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="text-center">STT</th>
                <th class="text-center">Mã Loại Hoạt Động</th>
                <th>Tên Loại Hoạt Động</th>
                <th>Mô Tả</th>
                <th class="text-center">Chức Năng</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $loaihoatdongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $loaihoatdong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td class="text-center"><?php echo e($loaihoatdong->MaLoaiHD); ?></td>
                    <td><?php echo e($loaihoatdong->TenLoaiHD); ?></td>
                    <td><?php echo e($loaihoatdong->MoTa); ?></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('loaihoatdong.edit', $loaihoatdong->MaLoaiHD)); ?>"
                            class="btn btn-warning btn-sm btn-edit-style">Sửa</a>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">Không có dữ liệu</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaihoatdong/index.blade.php ENDPATH**/ ?>