

<?php $__env->startSection('content'); ?>
    <h4>THÊM MỚI LOẠI KHÁCH HÀNG</h4>

    <!-- Form nhập thông tin loại khách hàng -->
    <fieldset class="border p-3 mb-3">
        <legend class="float-none w-auto px-2">Thông tin loại khách hàng</legend>
        <form method="POST" action="<?php echo e(route('loaikhachhang.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Mã Loại Khách Hàng</label>
                    <input type="text" name="MaLoaiKH" class="form-control" value="<?php echo e(old('MaLoaiKH')); ?>">
                    <?php $__errorArgs = ['MaLoaiKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tên Loại Khách Hàng</label>
                    <input type="text" name="TenLoaiKH" class="form-control" value="<?php echo e(old('TenLoaiKH')); ?>">
                    <?php $__errorArgs = ['TenLoaiKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Mô Tả</label>
                    <textarea name="MoTa" class="form-control"><?php echo e(old('MoTa')); ?></textarea>
                    <?php $__errorArgs = ['MoTa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
    </fieldset>

    <!-- Nút hành động -->
    <div class="text-end">
        <button class="btn btn-save btn-custom">Lưu</button>
        </form>
        <a href="<?php echo e(route('loaikhachhang.index')); ?>" class="btn btn-cancel btn-custom">Hủy</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaikhachhang/create.blade.php ENDPATH**/ ?>