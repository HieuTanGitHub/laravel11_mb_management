

<?php $__env->startSection('content'); ?>
    <h4>Thêm Mới Loại Thẻ</h4>

    <!-- Hiển thị lỗi validation -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('loaithe.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Mã Loại Thẻ</label>
            <input type="text" name="MaLoaiThe" class="form-control" value="<?php echo e(old('MaLoaiThe')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Tên Loại Thẻ</label>
            <input type="text" name="TenLoaiThe" class="form-control" value="<?php echo e(old('TenLoaiThe')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Lưu</button>
        <a href="<?php echo e(route('loaithe.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/loaithe/create.blade.php ENDPATH**/ ?>