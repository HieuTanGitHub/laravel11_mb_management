<table class="table table-bordered">
    <tr>
        <th>Mã Giao Dịch</th>
        <td><?php echo e($guitien->MaGDGuiTien); ?></td>
    </tr>
    <tr>
        <th>Số Tài Khoản</th>
        <td><?php echo e($guitien->SoTK); ?></td>
    </tr>
    <tr>
        <th>Chủ Tài Khoản</th>
        <td><?php echo e($khachhang->TenKH); ?></td>
    </tr>
    <tr>
        <th>CCCD</th>
        <td><?php echo e($khachhang->CCCD); ?></td>
    </tr>
    <tr>
        <th>Số Thẻ</th>
        <td><?php echo e($the->SoThe); ?></td>
    </tr>
    <tr>
        <th>Số Tiền Gửi</th>
        <td><?php echo e(number_format($guitien->SoTienGui)); ?> VNĐ</td>
    </tr>
    <tr>
        <th>Phí Giao Dịch</th>
        <td><?php echo e(number_format($guitien->PhiGiaoDich)); ?> VNĐ</td>
    </tr>
    <tr>
        <th>Nội Dung</th>
        <td><?php echo e($guitien->NoiDung); ?></td>
    </tr>
    <tr>
        <th>Ngày Tạo</th>
        <td><?php echo e($guitien->NgayTao); ?></td>
    </tr>
</table>
<?php /**PATH C:\xampp\htdocs\mb_management\resources\views/giaodich/guitien/chitiet.blade.php ENDPATH**/ ?>