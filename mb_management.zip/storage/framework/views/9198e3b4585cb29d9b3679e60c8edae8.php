

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h4 class="text-center mb-4 fw-bold">THÊM MỚI GIAO DỊCH GỬI TIỀN</h4>
        <div class="mb-3">
            <a href="<?php echo e(route('giaodich.ruttien')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('giaodich.guitien.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row g-3">
                <div class="col-md-3">
                    <label>Mã giao dịch</label>
                    <input type="text" class="form-control" name="MaGDGuiTien" readonly value="<?php echo e(rand(0000, 9999)); ?>">
                </div>

                <div class="col-md-3">
                    <label>Ngày tạo</label>
                    <input type="text" class="form-control" name="NgayTao" readonly value="<?php echo e(\Carbon\Carbon::now()); ?>">
                </div>

                <div class="col-md-3">
                    <label>Người tạo</label>
                    <input type="text" class="form-control" name="MaNV" readonly
                        value="<?php echo e(Session::get('TenDangNhap')); ?>">
                </div>

                <div class="col-md-3">
                    <label>Điểm giao dịch</label>
                    <input type="text" class="form-control" name="ViTri" readonly value="Tại Quầy">
                </div>
            </div>

            <h6 class="mt-4 fw-bold">Thông tin giao dịch</h6>

            <div class="row g-3">
                <div class="col-md-3">
                    <label>Số tài khoản *</label>
                    <select name="SoTK" class="form-control chonsotaikhoan">
                        <option>---Chọn tài khoản---</option>
                        <?php $__currentLoopData = $khachhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kh->khach?->SoTK); ?>"><?php echo e($kh->khach?->SoTK); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label>Tên chủ tài khoản</label>
                    <input type="text" class="form-control" id="TenKH" disabled>
                </div>

                <div class="col-md-2">
                    <label>CCCD</label>
                    <input type="text" class="form-control" id="CCCD" disabled>
                </div>

                <div class="col-md-2">
                    <label>Số thẻ</label>
                    <input type="text" class="form-control" id="SoThe" disabled>
                </div>

                <div class="col-md-2">
                    <label>Số dư tài khoản</label>
                    <input type="text" class="form-control" id="SoDuTK" disabled>
                </div>

                <div class="col-md-3">
                    <label>Số tiền gửi</label>
                    <input type="number" min="1000000" value="1000000" name="SoTienGui" placeholder=">1tr"
                        class="form-control">
                </div>

                <div class="col-md-3">
                    <label>Phí giao dịch</label>
                    <input type="text" min="0" name="PhiGiaoDich" value="10000" placeholder="0"
                        class="form-control">
                </div>

                <div class="col-md-6">
                    <label>Nội dung</label>
                    <textarea class="form-control" name="NoiDung" rows="3">Giao Dịch Gửi Tiền Tại Quầy.</textarea>
                </div>
            </div>

            <div class="mt-4 text-end">
                <a href="<?php echo e(route('giaodich.guitien')); ?>" class="btn btn-danger">
                    Hủy
                </a>
                <button type="submit" class="btn btn-primary">Tạo mới</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/giaodich/guitien/create.blade.php ENDPATH**/ ?>