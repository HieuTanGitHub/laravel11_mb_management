

<?php $__env->startSection('content'); ?>
    <h4>Thêm mới nhân viên</h4>

    <!-- Display validation errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form to add new employee -->
    <form action="<?php echo e(route('nhanvien.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Mã nhân viên</label>
                <input type="text" name="MaNV" class="form-control" value="<?php echo e(old('MaNV')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Họ và tên</label>
                <input type="text" name="HoTen" class="form-control" value="<?php echo e(old('HoTen')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Số điện thoại</label>
                <input type="text" name="SDT" class="form-control" value="<?php echo e(old('SDT')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Tên đăng nhập</label>
                <input type="text" name="TenDangNhap" class="form-control" value="<?php echo e(old('TenDangNhap')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Mật khẩu</label>
                <input type="password" name="MatKhau" class="form-control" value="<?php echo e(old('MatKhau')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="Email" class="form-control" value="<?php echo e(old('Email')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Phân quyền</label>
                <input type="text" name="PhanQuyen" class="form-control" value="<?php echo e(old('PhanQuyen')); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Mã phòng ban</label>
                <select name="MaPB" class="form-control">
                    <?php $__currentLoopData = $phongbans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phongban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($phongban->MaPB); ?>" <?php echo e(old('MaPB') == $phongban->MaPB ? 'selected' : ''); ?>>
                            <?php echo e($phongban->TenPB); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Mã chức vụ</label>
                <select name="MaCV" class="form-control">
                    <?php $__currentLoopData = $chucvus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chucvu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chucvu->MaCV); ?>" <?php echo e(old('MaCV') == $chucvu->MaCV ? 'selected' : ''); ?>>
                            <?php echo e($chucvu->TenCV); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <!-- Submit Button -->
        <div class="text-end">
            <button class="btn btn-save btn-custom">Lưu</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/nhanvien/create.blade.php ENDPATH**/ ?>