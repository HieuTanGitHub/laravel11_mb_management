

<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Chỉnh Sửa Phòng Ban</h4>

    <form method="POST" action="<?php echo e(route('phongban.update', $phongban->MaPB)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Mã Phòng Ban</label>
            <input type="text" name="MaPB" class="form-control" value="<?php echo e($phongban->MaPB); ?>" readonly>
        </div>

        <div class="mb-3">
            <label class="form-label">Tên Phòng Ban</label>
            <input type="text" name="TenPB" class="form-control" value="<?php echo e(old('TenPB', $phongban->TenPB)); ?>">
            <?php $__errorArgs = ['TenPB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Cập Nhật</button>
        <a href="<?php echo e(route('phongban.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/phongban/edit.blade.php ENDPATH**/ ?>