

<?php $__env->startSection('content'); ?>
    <h4>Thêm mới tài khoản</h4>

    <form method="POST" action="<?php echo e(route('taikhoan.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row g-3">
            <!-- Mã loại thẻ -->
            <div class="col-md-4">
                <label class="form-label">Mã loại thẻ</label>
                <select name="MaLoaiThe" class="form-control" required>
                    <option value="">Chọn mã loại thẻ</option>
                    <?php $__currentLoopData = $loaithe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loaiThe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loaiThe->MaLoaiThe); ?>"
                            <?php echo e(old('MaLoaiThe') == $loaiThe->MaLoaiThe ? 'selected' : ''); ?>>
                            <?php echo e($loaiThe->TenLoaiThe); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['MaLoaiThe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Mã nhân viên -->
            <div class="col-md-4">
                <label class="form-label">Mã nhân viên</label>
                <select name="MaNV" class="form-control" required>
                    <option value="">Chọn mã nhân viên</option>
                    <?php $__currentLoopData = $nhanvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($nv->MaNV); ?>" <?php echo e(old('MaNV') == $nv->MaNV ? 'selected' : ''); ?>>
                            <?php echo e($nv->HoTen); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['MaNV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Mã khách hàng -->
            <div class="col-md-4">
                <label class="form-label">Mã khách hàng</label>
                <select name="MaKH" class="form-control" required>
                    <option value="">Chọn mã khách hàng</option>
                    <?php $__currentLoopData = $khachhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kh->MaKH); ?>" <?php echo e(old('MaKH') == $kh->MaKH ? 'selected' : ''); ?>>
                            <?php echo e($kh->TenKH); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['MaKH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Số tài khoản -->
            <div class="col-md-4">
                <label class="form-label">Số tài khoản</label>
                <input type="number" name="SoTK" class="form-control" value="<?php echo e(old('SoTK')); ?>" required>
                <?php $__errorArgs = ['SoTK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Số dư tài khoản -->
            <div class="col-md-4">
                <label class="form-label">Số dư tài khoản</label>
                <input type="number" name="SoDuTK" class="form-control" value="<?php echo e(old('SoDuTK')); ?>" required>
                <?php $__errorArgs = ['SoDuTK'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <!-- Ngày mở -->
            <div class="col-md-4">
                <label class="form-label">Ngày mở</label>
                <input type="date" name="NgayMo" class="form-control" value="<?php echo e(old('NgayMo')); ?>" required>
                <?php $__errorArgs = ['NgayMo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Ngày đóng -->
            <div class="col-md-4">
                <label class="form-label">Ngày đóng</label>
                <input type="date" name="NgayDong" class="form-control" value="<?php echo e(old('NgayDong')); ?>">
                <?php $__errorArgs = ['NgayDong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Trạng thái -->
            <div class="col-md-4">
                <label class="form-label">Trạng thái</label>
                <select name="TrangThai" class="form-control">
                    <option value="1" <?php echo e(old('TrangThai', $the->TrangThai ?? '') == 1 ? 'selected' : ''); ?>>Còn hiệu
                        lực</option>
                    <option value="0" <?php echo e(old('TrangThai', $the->TrangThai ?? '') == 0 ? 'selected' : ''); ?>>Đã đóng
                    </option>
                </select>
                <?php $__errorArgs = ['TrangThai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <!-- Ngày tạo -->
            <div class="col-md-4">
                <label class="form-label">Ngày tạo</label>
                <input type="date" name="NgayTao" class="form-control" value="<?php echo e(old('NgayTao')); ?>" required>
                <?php $__errorArgs = ['NgayTao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="text-end mt-3">
            <button type="submit" class="btn btn-save btn-custom">Lưu</button>
            <a href="<?php echo e(route('taikhoan.index')); ?>" class="btn btn-cancel btn-custom">Hủy</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mb_management\resources\views/taikhoan/create.blade.php ENDPATH**/ ?>